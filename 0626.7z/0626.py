# print("Hello World!")

# x=2
# print(x)
# x=x+1
# print(x)
# y=4
# print(x+y)
# z=x+y
# print(z)
# print(x-y)
# print(x*y)
# print(x/y)
# print(x//y) #取商
# print(x%y) #取餘數

# string_1 = "hello world"
# string_1 = input("在這裡輸入字串:")
# string_1_upper = string_1.upper()
# print(string_1,string_1_upper)
# string_1_lower = string_1_upper.lower()
# print(string_1_upper,string_1_lower)
# string_1_title = string_1_lower.title()
# print(string_1_lower,string_1_title)
# string_1_title = string_1_upper.title()
# print(string_1_lower,string_1_title)

# sentence_1 = "I like to eat apple"
# sentence_2 = sentence_1.replace("apple","banana")
# print(sentence_2)

# sentence_1_split = sentence_1.split(" ")
# print(sentence_1_split)

list_a = [1,2,3,4,"5","6","7"]
print(len(list_a))
print(list_a[0],type(list_a[0]),list_a[4],type(list_a[4]),list_a[6],type(list_a[6]))
